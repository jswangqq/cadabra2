__version__ = "2.3.7"
SITE_PATH = "/usr/lib/python3.8/dist-packages"
